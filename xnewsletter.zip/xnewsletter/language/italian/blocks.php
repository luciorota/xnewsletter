<?php   
/**
 * ****************************************************************************
 *  XNEWSLETTER - MODULE FOR XOOPS
 *  Copyright (c) 2007 - 2012
 *  Goffy ( wedega.com )
 *
 *  You may not change or alter any portion of this comment or credits
 *  of supporting developers from this source code or any supporting
 *  source code which is considered copyrighted (c) material of the
 *  original comment or credit authors.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  ---------------------------------------------------------------------------
 *  @copyright  Goffy ( wedega.com )
 *  @license    GPL 2.0
 *  @package    xNewsletter
 *  @author     Goffy ( webmaster@wedega.com )
 *
 *  Version : 1 Mon 2012/11/05 14:31:32 :  Exp $
 * ****************************************************************************
 */
define('_MB_XNEWSLETTER_CATSUBSCR_ALLCAT',"Tutte le newsletter");
define('_MB_XNEWSLETTER_LETTER_DISPLAY',"Numero di messaggi email da visualizzare");
define('_MB_XNEWSLETTER_LETTER_TITLELENGTH',"Lunghezza indirizzo email e titolo messaggio email (0 nessun limite)");
define('_MB_XNEWSLETTER_LETTER_CATTODISPLAY',"Seleziona le newsletter da visualizzare");
