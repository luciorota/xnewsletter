<?php   
/**
 * ****************************************************************************
 *  - A Project by Developers TEAM For Xoops - ( http://www.xoops.org )
 * ****************************************************************************
 *  XNEWSLETTER - MODULE FOR XOOPS
 *  Copyright (c) 2007 - 2012
 *  Goffy ( wedega.com )
 *
 *  You may not change or alter any portion of this comment or credits
 *  of supporting developers from this source code or any supporting
 *  source code which is considered copyrighted (c) material of the
 *  original comment or credit authors.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  ---------------------------------------------------------------------------
 *  @copyright  Goffy ( wedega.com )
 *  @license    GPL 2.0
 *  @package    xNewsletter
 *  @author     Goffy ( webmaster@wedega.com )
 *
 *  Version : 1 Mon 2012/11/05 14:31:32 :  Exp $
 * ****************************************************************************
 */
// Main
    define('_MA_XNEWSLETTER_INDEX',"Home"); // NOT USED
define('_MA_XNEWSLETTER_TITLE',"xNewsletter");
define('_MA_XNEWSLETTER_DESC',"Modulo per la gestione di newsletter");
define('_MA_XNEWSLETTER_WELCOME',"<h2>Benvenuti nel nostro sistema di gestione newsletter</h2>Speriamo, con le nostre newsletter, di tenervi sempre informati. Il sistema consente di iscriversi a pi&ugrave; newsletter se sono disponibili. Se non desiderate pi&ugrave; ricevere le nostre newsletter &egrave; possibile cancellare l'iscrizione qui. &Egrave; anche possibile cancellare l'iscrizione cliccando il link presente nei messaggi email gia ricevuti.");
define('_MA_XNEWSLETTER_ACCOUNTS',"Account email");
define('_MA_XNEWSLETTER_CAT',"Categoria");
define('_MA_XNEWSLETTER_SUBSCR',"Abbonati");
    define('_MA_XNEWSLETTER_CATSUBSCR',"Subscriber Newsletter category"); // NOT USED
define('_MA_XNEWSLETTER_LETTER',"Messaggio email");
define('_MA_XNEWSLETTER_PROTOCOL',"Azione registrata");
define('_MA_XNEWSLETTER_BMH',"Gestore email errate/ritorni");
define('_MA_XNEWSLETTER_ADMIN',"Amministra");
define('_MA_XNEWSLETTER_LETTER_CATS',"Inviato con la newsletter");
define('_MA_XNEWSLETTER_SUBSCRIPTION_SEARCH',"Cerca iscritto");
define('_MA_XNEWSLETTER_SUBSCRIPTION_SEARCH_EMAIL',"Indirizzo email");
define('_AM_XNEWSLETTER_SUBSCRIPTION_SEARCH_ADD',"Cerca/Aggiungi iscritto");
define('_MA_XNEWSLETTER_SUBSCRIPTION_EXIST',"Iscrizioni esistenti");
define('_MA_XNEWSLETTER_SUBSCRIPTION_EXIST_NONE',"Non ci sono iscrizioni");
define('_MA_XNEWSLETTER_REGISTRATION_EXIST',"Attenzione: esiste gi&agrave; una iscrizione effettuata con questo indirizzo email.");
define('_MA_XNEWSLETTER_REGISTRATION_NONE',"Per ora il vostro indirizzo email non &egrave; stato registrato ma per questioni di sicurezza abbiamo registrato il vostro indirizzo IP. <br/>Per l&#39;iscrizione &egrave; necessario inserire ulteriori informazioni. <br/>Prego compilare il modulo di registrazione.");
    define('_MA_XNEWSLETTER_REGISTRATION_ADD',"If you want, you can add more than one person to one email, and later on you can make different suscriptions"); // NOT USED
define('_MA_XNEWSLETTER_SUBSCRIPTION_ADD',"Aggiungi iscrizione");
define('_MA_XNEWSLETTER_SUBSCRIPTION_EDIT',"Modifica iscrizione");
define('_MA_XNEWSLETTER_SUBSCRIPTION_DELETE',"Elimina iscrizione");
define('_MA_XNEWSLETTER_SUBSCRIPTION_DELETE_SURE',"Attenzione: si desidera veramente cancellare questo iscritto e tutte le sue iscrizioni?<br />Se si vuole solamente modificare l'iscrizione a una o più newsletter si prega di utilizzare il pulsante di modifica.<br />");
define('_MA_XNEWSLETTER_SUBSCRIPTION_INFO_PERS',"Informazioni personali");
define('_MA_XNEWSLETTER_SUBSCRIPTION_SELECT_CATS',"Selezionare la/le newsletter");
define('_MA_XNEWSLETTER_SUBSCRIPTION_CATS_AVAIL',"Newsletter disponibili");
define('_MA_XNEWSLETTER_SUBSCRIPTION_NO_CATS_AVAIL',"Non ci sono newsletter disponibili");
define('_MA_XNEWSLETTER_SUBSCRIPTION_OK',"Richiesta di iscrizione avvenuta con successo.");
define('_MA_XNEWSLETTER_SUBSCRIPTION_ERROR',"Errore: non &egrave; stato possibile completare l&#39;iscrizione/la cancellazione");
define('_MA_XNEWSLETTER_SUBSCRIPTION_ERROR_NOID',"Errore: 'subscr_id' non valido");
define('_MA_XNEWSLETTER_SUBSCRIPTION_ERROR_NOEMAIL',"Errore: indirizzo email non valido");
define('_MA_XNEWSLETTER_SUBSCRIPTION_ERROR_SENDACTKEY',"Errore: non &grave; stato possibile inviare il messaggio email di conferma");
define('_MA_XNEWSLETTER_SUBSCRIPTION_ERROR_SAVESUBSCR',"Errore: non &egrave; stato possibile registrare le informazioni personali");
define('_MA_XNEWSLETTER_SUBSCRIPTION_ERROR_INVALIDKEY',"Errore: 'actkey' formalmente non corretto");
define('_MA_XNEWSLETTER_SUBSCRIPTION_ERROR_NODATAKEY',"Errore: 'actkey' non corrisponde a nessun iscritto");
define('_MA_XNEWSLETTER_SUBSCRIPTION_ERROR_NOVALIDKEY',"Errore: 'actkey' ..."); // NOT USED
define('_MA_XNEWSLETTER_SUBSCRIPTION_ERROR_SAVECATSUBSCR',"Errore: non &egrave; stato possibile salvare/cancellare l&#39;iscrizione");
define('_MA_XNEWSLETTER_SUBSCRIPTION_REG_OK',"Dati registrazione acquisiti.");
define('_MA_XNEWSLETTER_SUBSCRIPTION_PROT_SUBSCRIBE',"Iscrizione alla newsletter &#39;%nl&#39; avvenuta con successo");
define('_MA_XNEWSLETTER_SUBSCRIPTION_PROT_UNSUBSCRIBE',"Cancellazione dalla newsletter &#39;%nl&#39; avvenuta con successo");
define('_MA_XNEWSLETTER_SUBSCRIPTION_PROT_NO_CHANGE',"Iscrizione alla newsletter &#39;%nl&#39; non modificata");
define('_MA_XNEWSLETTER_SUBSCRIPTION_PROT_DAT_QUITED_REMOVED',"Invio newsletter &#39;%nl&#39; ripristinato con successo");
define('_MA_XNEWSLETTER_SUBSCRIPTION_PROT_SENT_INFO',"Email informativa inviata a &#39;%e&#39;");
define('_MA_XNEWSLETTER_SUBSCRIPTION_QUITED',"<span style='color:red'>Attenzione: invio newsletter sospeso dagli amministratori del sito!</span>");
define('_MA_XNEWSLETTER_SUBSCRIPTION_QUITED_DETAIL',"<span style='color:red'>Attenzione: l'invio di questa newsletter alla vostra email è stato sospeso il %q per problemi di ricezione!<br />Se desiderate riattivare l'iscrizione, prego non deselezionare la newsletter.</span>");
define('_MA_XNEWSLETTER_UNSUBSCRIPTION_OK',"L&#39;indirizzo email &#39;%e&#39; &egrave; stato cancellato con successo dalla newsletter &#39;%n&#39;");
define('_MA_XNEWSLETTER_UNSUBSCRIPTION_ERROR',"Errore: non &egrave; stato possibile cancellare l'iscrizione dell'indirizzo email &#39;%e&#39; dalla newsletter &#39;%n&#39;");
define('_MA_XNEWSLETTER_SUBSCRIPTION_UPDATE_OK',"Dati aggiornamento acquisiti.");
define('_MA_XNEWSLETTER_SUBSCRIPTION_REG_CLOSED',"Iscrizione completata.");
define('_MA_XNEWSLETTER_SUBSCRIPTIONSUBJECT',"Conferma di iscrizione alla newsletter del sito ");
define('_MA_XNEWSLETTER_SUBSCRIPTION_SUBJECT_CHANGE',"Conferma di variazione di registrazione alla newsletter del sito ");
define('_MA_XNEWSLETTER_SENDMAIL_REG_OK',"Messaggio email con la richiesta di conferma per l'iscrizione inviato all&#39;indirizzo email '%subscr_email'. <br />Potrà completare la registrazione dall'email che riceverà a breve.");
define('_MA_XNEWSLETTER_DELETESUBJECT',"Conferma di cancellazione dalla newsletter del sito ");
define('_MA_XNEWSLETTER_SUBSCRIPTION_REG_UPDATE_CLOSED',"Aggiornamento completato.");
define('_MA_XNEWSLETTER_SENDMAIL_UNREG_OK',"Messaggio di conferma di cancellazione inviato all&#39;indirizzo email '%subscr_email'.");
define('_MA_XNEWSLETTER_SUBSCRIPTION_UNFINISHED',"<span style='color:red'>Attenzione: registrazione/iscrizione non confermata. <br />Cliccare il link di attivazione presente nel messaggio di conferma che abbiamo precedentemente inviato all'indirizzo email da voi inserito. <br />Se non avete ricevuto il messaggio di conferma o se l'avete cancellato <a href='%link'>cliccare qui</a> per riceverlo nuovamente.</span>");
define('_MA_XNEWSLETTER_PLEASE_LOGIN',"L&#39;indirizzo email %s appartiene ad un utente registrato. <br />Prego <a href='" . XOOPS_URL . "/user.php?xoops_redirect=/modules/xnewsletter/subscription.php'>accedere al sito con nome utente e password</a> per effettuare modifiche.");
define('_MA_XNEWSLETTER_LETTER_NONEAVAIL',"Non ci sono messaggi email");
//1.2.2
define('_MA_XNEWSLETTER_ACCOUNTS_NONEAVAIL',"Non ci sono email account");
//1.3
define('_MD_XNEWSLETTER_SUBSCRIBE',"Iscrivi/Cancella");
define('_MD_XNEWSLETTER_LIST',"Elenco messaggi email");
define('_MD_XNEWSLETTER_LIST_SUBSCR',"Elenca iscritti");
define('_MD_XNEWSLETTER_LETTER_CREATE',"Crea messaggio email");
define('_MD_XNEWSLETTER_LETTER_EDIT',"Modifica messaggio email");
define('_MD_XNEWSLETTER_LETTER_DELETE',"Elimina messaggio email");
define('_MD_XNEWSLETTER_LETTER_COPY',"Copia/clona messaggio email");
define('_MD_XNEWSLETTER_LETTER_PREVIEW',"Anteprima");
define('_MD_XNEWSLETTER_SUBSCRIPTION_EDIT',"Modifica iscrizione");
define('_MD_XNEWSLETTER_SUBSCRIPTION_DELETE',"Cancella iscrizione");
define('_MA_XNEWSLETTER_SUBSCRIPTION_CATS_AVAIL_DESC',"Selezionate/deselezionate la/le newsletter a cui desiderate essere iscritti/cancellati");
define('_MD_XNEWSLETTER_PROTOCOL',"Registro azioni");
define('_MD_XNEWSLETTER_OK',"Ok");
define('_MD_XNEWSLETTER_WARNING',"Attenzione");
define('_MD_XNEWSLETTER_ERROR',"Errore");
define('_MA_XNEWSLETTER_SUBSCRIPTION_ERROR_KEYEXPIRED',"Errore: 'actkey' scaduto, &egrave; necessario iscriversi nuovamente");
define('_MA_XNEWSLETTER_RESENDMAIL_REG_OK',"Messaggio di conferma inviato nuovamente all&#39;indirizzo email '%subscr_email'.");
