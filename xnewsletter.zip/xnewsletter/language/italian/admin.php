<?php   
/**
 * ****************************************************************************
 *  XNEWSLETTER - MODULE FOR XOOPS
 *  Copyright (c) 2007 - 2012
 *  Goffy ( wedega.com )
 *
 *  You may not change or alter any portion of this comment or credits
 *  of supporting developers from this source code or any supporting
 *  source code which is considered copyrighted (c) material of the
 *  original comment or credit authors.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  ---------------------------------------------------------------------------
 *  @copyright  Goffy ( wedega.com )
 *  @license    GPL 2.0
 *  @package    xNewsletter
 *  @author     Goffy ( webmaster@wedega.com )
 *
 *  Version : 1 Mon 2012/11/05 14:31:32 :  Exp $
 * ****************************************************************************
 */
//General
define('_AM_XNEWSLETTER_FORMOK',"Registrato con successo");
define('_AM_XNEWSLETTER_FORMDELOK',"Eliminato con successo");
    define('_AM_XNEWSLETTER_FORMDELNOTOK',"Error while deleting");
define('_AM_XNEWSLETTER_FORMSUREDEL',"Sei certo di voler eliminare: <span class='bold red'>%s</span>");
define('_AM_XNEWSLETTER_FORMSUREDEL_LIST',"Sei certo di voler eliminare le azioni registrate relative a: <span class='bold red'>%s</span>");
    define('_AM_XNEWSLETTER_FORMSURERENEW',"Sei certo di voler renew: <span class='bold red'>%s</span>");
define('_AM_XNEWSLETTER_FORMUPLOAD',"Upload");
define('_AM_XNEWSLETTER_FORMIMAGE_PATH',"File presenti in %s");
define('_AM_XNEWSLETTER_FORMACTION',"Azione");
define('_AM_XNEWSLETTER_ERROR_NO_VALID_ID',"Errore: id non valido!");
define('_AM_XNEWSLETTER_OK',"Positivo");
define('_AM_XNEWSLETTER_FAILED',"Negativo");
define('_AM_XNEWSLETTER_SAVE',"Salva");
define('_AM_XNEWSLETTER_DETAILS',"Visualizza dettagli");
define('_AM_XNEWSLETTER_SEARCH',"Filtra");
define('_AM_XNEWSLETTER_SEARCH_EQUAL',"=");
define('_AM_XNEWSLETTER_SEARCH_CONTAINS',"contiene");
define('_AM_XNEWSLETTER_ACCOUNTS_TYPE_PHPMAIL',"php mail()");
define('_AM_XNEWSLETTER_ACCOUNTS_TYPE_PHPSENDMAIL',"php sendmail()");
define('_AM_XNEWSLETTER_ACCOUNTS_TYPE_POP3',"pop before smtp");
define('_AM_XNEWSLETTER_ACCOUNTS_TYPE_SMTP',"smtp");
define('_AM_XNEWSLETTER_ACCOUNTS_TYPE_GMAIL',"gmail");
define('_AM_XNEWSLETTER_ACCOUNTS_TYPE_NOTREQUIRED',"Not required");
define('_AM_XNEWSLETTER_ACCOUNTS_TYPE_NAME',"Nome account email");
define('_AM_XNEWSLETTER_ACCOUNTS_TYPE_YOURNAME',"Paolo Rossi");
define('_AM_XNEWSLETTER_ACCOUNTS_TYPE_YOUREMAIL',"name@yourdomain.com");
define('_AM_XNEWSLETTER_ACCOUNTS_TYPE_USERNAME',"username");
define('_AM_XNEWSLETTER_ACCOUNTS_TYPE_PWD',"password");
define('_AM_XNEWSLETTER_ACCOUNTS_TYPE_POP3_SERVER_IN',"pop3.yourdomain.com");
define('_AM_XNEWSLETTER_ACCOUNTS_TYPE_POP3_PORT_IN',"110");
define('_AM_XNEWSLETTER_ACCOUNTS_TYPE_POP3_SERVER_OUT',"mail.yourdomain.com");
define('_AM_XNEWSLETTER_ACCOUNTS_TYPE_POP3_PORT_OUT',"25");
define('_AM_XNEWSLETTER_ACCOUNTS_TYPE_SMTP_SERVER_IN',"imap.yourdomain.com");
define('_AM_XNEWSLETTER_ACCOUNTS_TYPE_SMTP_PORT_IN',"143");
define('_AM_XNEWSLETTER_ACCOUNTS_TYPE_SMTP_SERVER_OUT',"mail.yourdomain.com");
define('_AM_XNEWSLETTER_ACCOUNTS_TYPE_SMTP_PORT_OUT',"25");
define('_AM_XNEWSLETTER_ACCOUNTS_TYPE_GMAIL_USERNAME',"yourusername@gmail.com");
define('_AM_XNEWSLETTER_ACCOUNTS_TYPE_GMAIL_SERVER_IN',"imap.gmail.com");
define('_AM_XNEWSLETTER_ACCOUNTS_TYPE_GMAIL_PORT_IN',"993");
define('_AM_XNEWSLETTER_ACCOUNTS_TYPE_SECURETYPE_IN',"tls");
define('_AM_XNEWSLETTER_ACCOUNTS_TYPE_GMAIL_SERVER_OUT',"smtp.gmail.com");
define('_AM_XNEWSLETTER_ACCOUNTS_TYPE_GMAIL_PORT_OUT',"465");
define('_AM_XNEWSLETTER_ACCOUNTS_TYPE_SECURETYPE_OUT',"ssl");
    define('_AM_XNEWSLETTER_ACCOUNTS_TYPE_CHECK',"Check the settings");
define('_AM_XNEWSLETTER_LETTER_ACTION',"Dopo il salvataggio ...");
define('_AM_XNEWSLETTER_LETTER_ACTION_SAVED',"Salvato");
define('_AM_XNEWSLETTER_LETTER_ACTION_NO',"Nessuna azione");
define('_AM_XNEWSLETTER_LETTER_ACTION_COPYNEW',"Copia e modifica");
define('_AM_XNEWSLETTER_LETTER_ACTION_PREVIEW',"Visualizza anteprima");
define('_AM_XNEWSLETTER_LETTER_ACTION_SEND',"Invia messaggio email a tutti gli iscritti");
define('_AM_XNEWSLETTER_LETTER_ACTION_RESEND',"Invia nuovamente il messaggio email agli iscritti, qualora il precedente invio non fosse avvenuto con successo");
define('_AM_XNEWSLETTER_LETTER_ACTION_SENDTEST',"Invia messaggio email solo all&#39;indirizzo email di test");
define('_AM_XNEWSLETTER_LETTER_EMAIL_TEST',"Indirizzo email di test");
define('_AM_XNEWSLETTER_LETTER_EMAIL_ALTBODY',"Attenzione: per leggere questo messaggio utilizzare un client compatibile con formato HTML");
define('_AM_XNEWSLETTER_LETTER_ERROR_INVALID_ATT_ID',"Errore: allegato non eliminato (id allegato non valido)");
define('_AM_XNEWSLETTER_SEND_SUCCESS',"Messaggio email correttamente inviato");
define('_AM_XNEWSLETTER_SEND_SUCCESS_TEST',"Messaggio email correttamente inviato a indirizzo email di test");
define('_AM_XNEWSLETTER_SEND_SUCCESS_NUMBER',"Inviati/o correttamente &#39;%t&#39; messaggi/o email");
define('_AM_XNEWSLETTER_SEND_SUCCESS_ML',"Mailing list gestita correttamente");
define('_AM_XNEWSLETTER_SEND_SUCCESS_ML_DETAIL',"Inviati correttamente &#39;%a'&#39; messaggi email a mailing list");
define('_AM_XNEWSLETTER_SEND_ERROR_NUMBER',"Errore: &#39;%e&#39; messaggi/o email su &#39;%t&#39; non inviati/o");
define('_AM_XNEWSLETTER_SEND_ERROR_PHPMAILER',"Errore phpmailer: ");
define('_AM_XNEWSLETTER_SEND_ERROR_NO_EMAIL',"Errore: indirizzo email non disponibile");
define('_AM_XNEWSLETTER_SEND_ERROR_NO_LETTERID',"Errore: selezionato messaggio email non valido");
define('_AM_XNEWSLETTER_SEND_ERROR_INALID_TEMPLATE_PATH',"Errore: modello non presente al percorso '%p'");
define('_AM_XNEWSLETTER_SEND_SURE_SENT',"Messaggio email gi&agrave; inviato agli iscritti.<br />Sei sicuro di volerlo inviare nuovamente?");
define('_AM_XNEWSLETTER_SEND_ERROR_NO_SUBSCR',"Errore: nessuna iscrizione attiva a questa newsletter");
//Index
define('_AM_XNEWSLETTER_LETTER',"Statistiche");
define('_AM_XNEWSLETTER_THEREARE_ACCOUNTS',"Ci sono <span class='bold'>%s</span> account email nel database");
define('_AM_XNEWSLETTER_THEREARE_CAT',"Ci sono <span class='bold'>%s</span> newsletter nel database");
define('_AM_XNEWSLETTER_THEREARE_SUBSCR',"Ci sono <span class='bold'>%s</span> iscritti nel database");
define('_AM_XNEWSLETTER_THEREARE_CATSUBSCR',"Ci sono <span class='bold'>%s</span> iscrizioni nel database");
define('_AM_XNEWSLETTER_THEREARE_LETTER',"Ci sono <span class='bold'>%s</span> messaggi email nel database");
define('_AM_XNEWSLETTER_THEREARE_PROTOCOL',"Ci sono <span class='bold'>%s</span> azioni registrate nel database");
define('_AM_XNEWSLETTER_THEREARE_ATTACHMENT',"Ci sono <span class='bold'>%s</span> allegati nel database");
define('_AM_XNEWSLETTER_THEREARE_MAILINGLIST',"Ci sono <span class='bold'>%s</span> mailing list nel database");
define('_AM_XNEWSLETTER_THEREARE_BMH',"Ci sono <span class='bold'>%s</span> email errate/ritorni nel database");
define('_AM_XNEWSLETTER_THEREARE_TASK',"Ci sono <span class='bold'>%s</span> task nel database");
//Buttons
define('_AM_XNEWSLETTER_NEWACCOUNTS',"Aggiungi account email");
define('_AM_XNEWSLETTER_ACCOUNTSLIST',"Elenco account email");
define('_AM_XNEWSLETTER_ACCOUNTSWAIT',"Account email in attesa");
define('_AM_XNEWSLETTER_NEWCAT',"Aggiungi newsletter");
define('_AM_XNEWSLETTER_CATLIST',"Elenca newsletter");
define('_AM_XNEWSLETTER_CATWAIT',"Newsletter in attesa");
define('_AM_XNEWSLETTER_NEWSUBSCR',"Aggiungi iscritto");
define('_AM_XNEWSLETTER_SUBSCRLIST',"Elenco iscritti");
define('_AM_XNEWSLETTER_SUBSCRWAIT',"Iscritti in attesa");
define('_AM_XNEWSLETTER_NEWCATSUBSCR',"Aggiungi iscrizione");
define('_AM_XNEWSLETTER_CATSUBSCRLIST',"Elenco iscrizioni");
define('_AM_XNEWSLETTER_CATSUBSCRWAIT',"Iscrizione in attesa");
define('_AM_XNEWSLETTER_NEWLETTER',"Aggiungi messaggio email");
define('_AM_XNEWSLETTER_LETTERLIST',"Elenca messaggi email");
define('_AM_XNEWSLETTER_LETTERWAIT',"Messaggi email in attesa");
define('_AM_XNEWSLETTER_LETTER_DELETE_ALL',"Elimina azioni registrate per questo messaggio email");
define('_AM_XNEWSLETTER_NEWPROTOCOL',"Aggiungi azione");
define('_AM_XNEWSLETTER_PROTOCOLLIST',"Elenco azioni");
define('_AM_XNEWSLETTER_PROTOCOLWAIT',"Azioni in attesa");
define('_AM_XNEWSLETTER_NEWATTACHMENT',"Aggiungi allegato");
define('_AM_XNEWSLETTER_ATTACHMENTLIST',"Elenco allegati");
define('_AM_XNEWSLETTER_ATTACHMENTWAIT',"Allegati in attesa");
define('_AM_XNEWSLETTER_NEWMAILINGLIST',"Aggiungi mailing list");
define('_AM_XNEWSLETTER_MAILINGLISTLIST',"Elenca mailing list");
define('_AM_XNEWSLETTER_MAILINGLISTWAIT',"Mailing list in attesa");
define('_AM_XNEWSLETTER_RUNBMH',"Esegui gestore email errate/ritorni");
define('_AM_XNEWSLETTER_BMHLIST',"Elenco gestori email errate/ritorni");
define('_AM_XNEWSLETTER_BMHWAIT',"Email errate/ritorni in attesa");
define('_AM_XNEWSLETTER_ACCOUNTS_ADD',"Aggiungi account email");
define('_AM_XNEWSLETTER_ACCOUNTS_EDIT',"Modifica account email");
define('_AM_XNEWSLETTER_ACCOUNTS_DELETE',"Elimina account email");
define('_AM_XNEWSLETTER_ACCOUNTS_ID',"Id");
define('_AM_XNEWSLETTER_ACCOUNTS_TYPE',"Tipologia");
define('_AM_XNEWSLETTER_ACCOUNTS_NAME',"Nome account email");
define('_AM_XNEWSLETTER_ACCOUNTS_YOURNAME',"Nome utente");
define('_AM_XNEWSLETTER_ACCOUNTS_YOURMAIL',"Indirizzo email");
define('_AM_XNEWSLETTER_ACCOUNTS_USERNAME',"Nome utente");
define('_AM_XNEWSLETTER_ACCOUNTS_PASSWORD',"Password");
    define('_AM_XNEWSLETTER_ACCOUNTS_INCOMING',"Incoming");
    define('_AM_XNEWSLETTER_ACCOUNTS_SERVER_IN',"Server incoming");
    define('_AM_XNEWSLETTER_ACCOUNTS_PORT_IN',"Port in");
    define('_AM_XNEWSLETTER_ACCOUNTS_SECURETYPE_IN',"Securetype in");
    define('_AM_XNEWSLETTER_ACCOUNTS_OUTGOING',"Outgoing");
    define('_AM_XNEWSLETTER_ACCOUNTS_SERVER_OUT',"Server outgoing");
    define('_AM_XNEWSLETTER_ACCOUNTS_PORT_OUT',"Port out");
    define('_AM_XNEWSLETTER_ACCOUNTS_SECURETYPE_OUT',"Securetype out");
define('_AM_XNEWSLETTER_ACCOUNTS_DEFAULT',"Account email principale");
define('_AM_XNEWSLETTER_ACCOUNTS_BOUNCE_INFO',"Informazioni addizionali gestore email errate/ritorni");
    define('_AM_XNEWSLETTER_ACCOUNTS_USE_BMH',"Use Bounced emails handling");
    define('_AM_XNEWSLETTER_ACCOUNTS_INBOX',"Mailbox to check for Bounced emails");
    define('_AM_XNEWSLETTER_ACCOUNTS_HARDBOX',"Use this mailbox as 'hard box'");
    define('_AM_XNEWSLETTER_ACCOUNTS_HARDBOX_DESC',"The mailbox name must start with 'INBOX.'. You can select a standard folder in your mailbox (e.g. INBOX.Trash) or create your own special folders like 'hard' and 'soft'. If you type in a new folder name, the folder will be created (this function is not available for gmail-accounts).");
    define('_AM_XNEWSLETTER_ACCOUNTS_MOVEHARD',"Move Bounced email in 'hard box'");
    define('_AM_XNEWSLETTER_ACCOUNTS_SOFTBOX',"Use this mailbox as 'soft box'");
    define('_AM_XNEWSLETTER_ACCOUNTS_MOVESOFT',"Move Bounced email in 'soft box'");
define('_AM_XNEWSLETTER_ACCOUNTS_SUBMITTER',"Creato da");
define('_AM_XNEWSLETTER_ACCOUNTS_CREATED',"Creato in data");
    define('_AM_XNEWSLETTER_ACCOUNTS_ERROR_OPEN_MAILBOX',"Error open mailbox! Please check your settings!");
define('_AM_XNEWSLETTER_SAVE_AND_CHECK',"Salva e controlla impostazioni");
define('_AM_XNEWSLETTER_ACCOUNTS_CHECK_OK',"con successo  ");
    define('_AM_XNEWSLETTER_ACCOUNTS_CHECK_FAILED',"failed  ");
    define('_AM_XNEWSLETTER_ACCOUNTS_CHECK_SKIPPED',"skipped");
    define('_AM_XNEWSLETTER_ACCOUNTS_CHECK',"Check result");
define('_AM_XNEWSLETTER_ACCOUNTS_CHECK_INFO',"Informazioni addizionali");
    define('_AM_XNEWSLETTER_ACCOUNTS_CHECK_OPEN_MAILBOX',"Open mailbox ");
    define('_AM_XNEWSLETTER_ACCOUNTS_CHECK_OPEN_FOLDERS',"Open folders ");
    define('_AM_XNEWSLETTER_ACCOUNTS_CHECK_BMH',"Bounced email handler ");
define('_AM_XNEWSLETTER_ACCOUNTS_CHECK_BMH_INBOX',"Mailbox");
define('_AM_XNEWSLETTER_ACCOUNTS_CHECK_BMH_HARDBOX',"Hardbox");
define('_AM_XNEWSLETTER_ACCOUNTS_CHECK_BMH_SOFTBOX',"Softbox");
define('_AM_XNEWSLETTER_CAT_ADD',"Aggiungi newsletter");
define('_AM_XNEWSLETTER_CAT_EDIT',"Modifica newsletter");
define('_AM_XNEWSLETTER_CAT_DELETE',"Elimina newsletter");
define('_AM_XNEWSLETTER_CAT_ID',"Id");
define('_AM_XNEWSLETTER_CAT_NAME',"Nome newsletter");
define('_AM_XNEWSLETTER_CAT_INFO',"Descrizione");
define('_AM_XNEWSLETTER_CAT_GPERMS_CREATE',"Gruppi che possono creare");
define('_AM_XNEWSLETTER_CAT_GPERMS_CREATE_DESC',"<br /><span style='font-weight:normal'>- Creare nuovi messaggi email<br />- Modificare, eliminare, inviare i propri messaggi email</span>");
define('_AM_XNEWSLETTER_CAT_GPERMS_ADMIN',"Gruppi che possono amministrare");
define('_AM_XNEWSLETTER_CAT_GPERMS_ADMIN_DESC',"<br /><span style='font-weight:normal'>Modificare, eliminare e inviare tutti i messaggi email di questa newsletter</span>");
define('_AM_XNEWSLETTER_CAT_GPERMS_READ',"Gruppi che possono leggere/iscriversi");
define('_AM_XNEWSLETTER_CAT_GPERMS_LIST',"Gruppi che possono vedere l'elenco degli iscritti");
define('_AM_XNEWSLETTER_CAT_SUBMITTER',"Creata da");
define('_AM_XNEWSLETTER_CAT_CREATED',"Creata in data");
define('_AM_XNEWSLETTER_CAT_MAILINGLIST',"Mailing list");
define('_AM_XNEWSLETTER_SUBSCR_ADD',"Aggiungi iscritto");
define('_AM_XNEWSLETTER_SUBSCR_EDIT',"Modifica iscritto");
define('_AM_XNEWSLETTER_SUBSCR_DELETE',"Elimina iscritto");
define('_AM_XNEWSLETTER_SUBSCR_ID',"Id");
define('_AM_XNEWSLETTER_SUBSCR_EMAIL',"Indirizzo email iscritto");
define('_AM_XNEWSLETTER_SUBSCR_FIRSTNAME',"Nome iscritto");
define('_AM_XNEWSLETTER_SUBSCR_LASTNAME',"Cognome iscritto");
define('_AM_XNEWSLETTER_SUBSCR_UID',"Nome utente");
define('_AM_XNEWSLETTER_SUBSCR_SEX',"Titolo iscritto");
define('_AM_XNEWSLETTER_SUBSCR_SEX_EMPTY',"");
define('_AM_XNEWSLETTER_SUBSCR_SEX_MALE',"Sig.");
define('_AM_XNEWSLETTER_SUBSCR_SEX_FEMALE',"Sig.ra");
define('_AM_XNEWSLETTER_SUBSCR_SEX_FAMILY',"Fam.");
define('_AM_XNEWSLETTER_SUBSCR_SEX_COMP',"Compagnia");
define('_AM_XNEWSLETTER_SUBSCR_SUBMITTER',"Creato da");
define('_AM_XNEWSLETTER_SUBSCR_CREATED',"Creato in data");
define('_AM_XNEWSLETTER_SUBSCR_ACTIVATED',"Iscritto attivo?");
define('_AM_XNEWSLETTER_SUBSCR_SHOW_ALL',"Mostra tutti");
define('_AM_XNEWSLETTER_CATSUBSCR_ADD',"Aggiungi iscrizione");
define('_AM_XNEWSLETTER_CATSUBSCR_EDIT',"Modifica iscrizione");
define('_AM_XNEWSLETTER_CATSUBSCR_DELETE',"Elimina iscrizione");
define('_AM_XNEWSLETTER_CATSUBSCR_ID',"Id");
define('_AM_XNEWSLETTER_CATSUBSCR_CATID',"Newsletter");
define('_AM_XNEWSLETTER_CATSUBSCR_SUBSCRID',"Iscritto");
define('_AM_XNEWSLETTER_CATSUBSCR_QUITED',"Sospeso");
define('_AM_XNEWSLETTER_CATSUBSCR_SUBMITTER',"Creata da");
define('_AM_XNEWSLETTER_CATSUBSCR_CREATED',"Creata in data");
define('_AM_XNEWSLETTER_CATSUBSCR_SUREDELETE',"Sei certo di voler eliminare<br />&#39;%s&#39;<br />da<br />&#39;%c&#39;?");
define('_AM_XNEWSLETTER_CATSUBSCR_QUIT_NONE',"Iscrivi");
define('_AM_XNEWSLETTER_CATSUBSCR_QUIT_NOW',"Sospendi invio");
define('_AM_XNEWSLETTER_CATSUBSCR_QUIT_REMOVE',"Ripristina invio sospeso il ");
define('_AM_XNEWSLETTER_LETTER_ADD',"Aggiungi messaggio email");
define('_AM_XNEWSLETTER_LETTER_EDIT',"Modifica messaggio email");
define('_AM_XNEWSLETTER_LETTER_DELETE',"Elimina messaggio email");
define('_AM_XNEWSLETTER_LETTER_ID',"Id");
define('_AM_XNEWSLETTER_LETTER_TITLE',"Titolo messaggio email");
define('_AM_XNEWSLETTER_LETTER_CONTENT',"Contenuto");
define('_AM_XNEWSLETTER_LETTER_TEMPLATE',"Modello");
define('_AM_XNEWSLETTER_LETTER_CATS',"Newsletter");
define('_AM_XNEWSLETTER_LETTER_ATTACHMENT',"Allegati");
define('_AM_XNEWSLETTER_LETTER_STATUS',"Stato");
define('_AM_XNEWSLETTER_LETTER_SUBMITTER',"Creato da");
define('_AM_XNEWSLETTER_LETTER_CREATED',"Creato in data");
define('_AM_XNEWSLETTER_LETTER_ACCOUNTS_AVAIL',"Account email disponibili");
define('_AM_XNEWSLETTER_LETTER_ACCOUNT',"Account email");
    define('_AM_XNEWSLETTER_LETTER_MAILINGLIST',"Use mailing list");
    define('_AM_XNEWSLETTER_LETTER_MAILINGLIST_NO',"None");
define('_AM_XNEWSLETTER_ATTACHMENT_ADD',"Aggiungi allegato");
define('_AM_XNEWSLETTER_ATTACHMENT_EDIT',"Modifica allegato");
define('_AM_XNEWSLETTER_ATTACHMENT_DELETE',"Elimina allegato");
define('_AM_XNEWSLETTER_ATTACHMENT_ID',"Id");
define('_AM_XNEWSLETTER_ATTACHMENT_LETTER_ID',"Titolo messaggio email");
define('_AM_XNEWSLETTER_ATTACHMENT_NAME',"Nome allegato");
define('_AM_XNEWSLETTER_ATTACHMENT_TYPE',"Mime-type");
define('_AM_XNEWSLETTER_ATTACHMENT_SUBMITTER',"Creato da");
define('_AM_XNEWSLETTER_ATTACHMENT_CREATED',"Inviato in data");
define('_AM_XNEWSLETTER_PROTOCOL_ADD',"Aggiungi azione");
define('_AM_XNEWSLETTER_PROTOCOL_EDIT',"Modifica azione");
define('_AM_XNEWSLETTER_PROTOCOL_DELETE',"Elimina azione");
define('_AM_XNEWSLETTER_PROTOCOL_ID',"Id");
define('_AM_XNEWSLETTER_PROTOCOL_LETTER_ID',"Id - Messaggio email");
define('_AM_XNEWSLETTER_PROTOCOL_SUBSCRIBER_ID',"Id - Iscritti");
define('_AM_XNEWSLETTER_PROTOCOL_STATUS',"Azione");
define('_AM_XNEWSLETTER_PROTOCOL_SUCCESS',"Esito");
define('_AM_XNEWSLETTER_PROTOCOL_SUBMITTER',"Registrata da");
define('_AM_XNEWSLETTER_PROTOCOL_CREATED',"Registrata in data");
define('_AM_XNEWSLETTER_PROTOCOL_LAST_STATUS',"Ultima azione registrata");
define('_AM_XNEWSLETTER_PROTOCOL_MISC',"Altre azioni");
    define('_AM_XNEWSLETTER_PROTOCOL_NO_SUBSCREMAIL',"No email of recipient found");
define('_AM_XNEWSLETTER_MAILINGLIST_ADD',"Aggiungi mailing list");
define('_AM_XNEWSLETTER_MAILINGLIST_EDIT',"Modifica mailing list");
define('_AM_XNEWSLETTER_MAILINGLIST_DELETE',"Elimina mailing list");
define('_AM_XNEWSLETTER_MAILINGLIST_ID',"Id");
define('_AM_XNEWSLETTER_MAILINGLIST_NAME',"Nome mailing list");
define('_AM_XNEWSLETTER_MAILINGLIST_EMAIL',"Email");
define('_AM_XNEWSLETTER_MAILINGLIST_EMAIL_DESC',"Email mailing list");
define('_AM_XNEWSLETTER_MAILINGLIST_LISTNAME',"Nome mailing list");
define('_AM_XNEWSLETTER_MAILINGLIST_SUBSCRIBE',"Codice di iscrizione");
define('_AM_XNEWSLETTER_MAILINGLIST_SUBSCRIBE_DESC',"Il tag {email} sar&agrave; rimpiazzato dall&#39;indirizzo email dell&#39;iscritto");
define('_AM_XNEWSLETTER_MAILINGLIST_UNSUBSCRIBE',"Codice di disiscrizione");
define('_AM_XNEWSLETTER_MAILINGLIST_SUBMITTER',"Creata da");
define('_AM_XNEWSLETTER_MAILINGLIST_CREATED',"Creata in data");
    define('_AM_XNEWSLETTER_BOUNCETYPE',"Bounce type");
define('_AM_XNEWSLETTER_BMH_EDIT',"Modifica gestore email errate/ritorni");
define('_AM_XNEWSLETTER_BMH_DELETE',"Elimina gestore email errate/ritorni");
define('_AM_XNEWSLETTER_BMH_ID',"Id");
    define('_AM_XNEWSLETTER_BMH_RULE_NO',"Rule no");
    define('_AM_XNEWSLETTER_BMH_RULE_CAT',"Rule cat");
    define('_AM_XNEWSLETTER_BMH_BOUNCETYPE',"Bounce type");
define('_AM_XNEWSLETTER_BMH_REMOVE',"Rimosso");
define('_AM_XNEWSLETTER_BMH_EMAIL',"Email");
define('_AM_XNEWSLETTER_BMH_SUBJECT',"Soggetto");
    define('_AM_XNEWSLETTER_BMH_MEASURE',"Measure");
define('_AM_XNEWSLETTER_BMH_SUBMITTER',"Creato da");
define('_AM_XNEWSLETTER_BMH_CREATED',"Creato in data");
define('_AM_XNEWSLETTER_BMH_MEASURE_PENDING',"In attesa");
define('_AM_XNEWSLETTER_BMH_MEASURE_NOTHING',"Nessuna azione");
define('_AM_XNEWSLETTER_BMH_MEASURE_QUIT',"Sospendi temporaneamente iscritto");
define('_AM_XNEWSLETTER_BMH_MEASURE_DELETE',"Elimina iscritto");
define('_AM_XNEWSLETTER_BMH_MEASURE_QUITED',"Iscritti temporaneamete sospesi");
define('_AM_XNEWSLETTER_BMH_MEASURE_DELETED',"Iscritti eliminati");
define('_AM_XNEWSLETTER_BMH_MEASURE_ALREADY_DELETED',"Iscritto gia eliminato! Azione non possibile!");
    define('_AM_XNEWSLETTER_BMH_MEASURE_DELETE_SURE',"Do you really want to delete this registration with all subscriptions?<br /><br />Reactivating by the subscriber will not be possible later!<br /><br />");
    define('_AM_XNEWSLETTER_BMH_ERROR_NO_SUBSCRID',"There is nor existing registration for the this email!");
    define('_AM_XNEWSLETTER_BMH_ERROR_NO_ACTIVE',"Bounced email handler isn't activated in any account email");
    define('_AM_XNEWSLETTER_BMH_RSLT',"Result of checking mailbox %b<br />Messages read: %r<br />Action taken: %a<br />No action taken: %n<br />Moved: %m<br />Deleted: %d<br /><br /><br />");
    define('_AM_XNEWSLETTER_BMH_SUCCESSFUL',"Bounced email handler successfully finished");
define('_AM_XNEWSLETTER_BMH_MEASURE_ALL',"Mostra tutti");
    define('_AM_XNEWSLETTER_BMH_MEASURE_SHOW_NONE',"Non ci sono email errate/ritorni '%s'");
define('_AM_XNEWSLETTER_MAINTENANCE_CAT',"Categoria");
define('_AM_XNEWSLETTER_MAINTENANCE_DESCR',"Descrizione");
define('_AM_XNEWSLETTER_MAINTENANCE_PARAM',"Parametri");
    define('_AM_XNEWSLETTER_MAINTENANCE_ERROR',"Error while running maintenance");
define('_AM_XNEWSLETTER_MAINTENANCE_DELETEDATE',"Elimina tutte le iscrizioni effettuate prima di questa data <b> e non confermate</b>.<br />Attentione: questo processo è irreversibile, controllare bene la data prima di procedere!");
    define('_AM_XNEWSLETTER_MAINTENANCE_DELETEUSER',"Should these <b>%s</b> unconfirmed registrations with date before %s really deleted.<br />Attention: there is no undo possible!");
define('_AM_XNEWSLETTER_MAINTENANCE_DELETEPROTOCOL',"Elimina tutte le azioni registrate e resetta il database");
    define('_AM_XNEWSLETTER_MAINTENANCE_DELETEPROTOK',"Tabella azioni registrate maintained.");
define('_AM_XNEWSLETTER_MAINTENANCE_DELETENOTHING',"Nessuna azione richiesta");
    define('_AM_XNEWSLETTER_MAINTENANCE_DELETEUSEROK',"%s Users have been deleted");
define('_AM_XNEWSLETTER_MAINTENANCE_DELETE_INVALID_SUBCR',"Elimina le iscrizioni alle quali non corrisponde alcun iscritto");
define('_AM_XNEWSLETTER_MAINTENANCE_DELETE_INVALID_SUBCR_OK',"Sono state eliminate %s iscrizioni");
    define('_AM_XNEWSLETTER_MAINTENANCE_DELETE_INVALID_SUBCR_NODATA',"No invalid data in table catsubsr found");
    define('_AM_XNEWSLETTER_MAINTENANCE_DELETE_INVALID_ML',"Compare data from newsletter cats with mailing lists and correct invalid data");
    define('_AM_XNEWSLETTER_MAINTENANCE_DELETE_INVALID_ML_OK',"%s wrong data in mailing list have been corrected");
    define('_AM_XNEWSLETTER_MAINTENANCE_DELETE_INVALID_ML_NODATA',"No invalid data mailing list found");
    define('_AM_XNEWSLETTER_MAINTENANCE_DELETE_INVALID_CATNL',"Compare data from newsletter cats with newsletters and correct invalid data");
    define('_AM_XNEWSLETTER_MAINTENANCE_DELETE_INVALID_CATNL_OK',"%s wrong data in newsletters have been corrected");
    define('_AM_XNEWSLETTER_MAINTENANCE_DELETE_INVALID_CATNL_NODATA',"No invalid data newsletters found");
define('_AM_XNEWSLETTER_MAINTENANCE_DELETE_IMPORT',"Resetta la tabella d&#39;importazione");
    define('_AM_XNEWSLETTER_MAINTENANCE_DELETE_IMPORT_OK',"Tabella d&#39;importazione resettata");
define('_AM_XNEWSLETTER_IMPORT_SEARCH',"Importa e iscrivi indirizzi email");
define('_AM_XNEWSLETTER_IMPORT_PRESELECT_CAT',"Selezionare la newsletter dove importare gli indirizzi email");
define('_AM_XNEWSLETTER_IMPORT_PLUGINS_AVAIL',"Visualizza plug-in d&#39;importazione");
define('_AM_XNEWSLETTER_IMPORT_CONTINUE',"Continua");
define('_AM_XNEWSLETTER_IMPORT_AFTER_READ',"Verifica indirizzi email");
define('_AM_XNEWSLETTER_IMPORT_READ_CHECK',"Verifica e poi importa");
define('_AM_XNEWSLETTER_IMPORT_CHECK_LIMIT',"Massimo numero di indirizzi email importabili");
define('_AM_XNEWSLETTER_IMPORT_CHECK_LIMIT_PACKAGE',"Numero indirizzi email importati alla volta");
define('_AM_XNEWSLETTER_IMPORT_NOLIMIT',"Nessuna limitazione");
define('_AM_XNEWSLETTER_IMPORT_READ_IMPORT',"Importa senza verificare");
    define('_AM_XNEWSLETTER_IMPORT_SHOW',"Visualizza da %s a %l di %n indirizzi email disponibili");
    define('_AM_XNEWSLETTER_IMPORT_NODATA',"No data found");
define('_AM_XNEWSLETTER_IMPORT_EMAIL_EXIST',"Indirizzo email gi&agrave; presente");
define('_AM_XNEWSLETTER_IMPORT_CATSUBSCR_EXIST',"Iscrizione gi&agrave; attiva");
    define('_AM_XNEWSLETTER_IMPORT_NOIMPORT',"-- No import --");
define('_AM_XNEWSLETTER_IMPORT_EXEC',"Importa");
    define('_AM_XNEWSLETTER_IMPORT_RESULT_SKIP',"Attenzione: Import email addresses %e skipped");
    define('_AM_XNEWSLETTER_IMPORT_RESULT_FAILED',"Attenzione: import email addresses %e failed");
    define('_AM_XNEWSLETTER_IMPORT_RESULT_REG_OK',"Registration successful");
    define('_AM_XNEWSLETTER_IMPORT_RESULT_SUBSCR_OK',"Subscription to category successful");
define('_AM_XNEWSLETTER_IMPORT_SKIP_EXISTING',"Ometti controllo iscrizioni gi&agrave; presenti");
define('_AM_XNEWSLETTER_IMPORT_FINISHED',"Importati %p di %t indirizzi email");
define('_AM_XNEWSLETTER_IMPORT_INFO',"Aggiungi tutti gli utenti di un gruppo alla newsletter");
define('_AM_XNEWSLETTER_IMPORT_CSV_OPT',"Opzioni di importazione file CSV");
define('_AM_XNEWSLETTER_IMPORT_CSV_FILE',"File CSV");
define('_AM_XNEWSLETTER_IMPORT_CSV_DELIMITER',"Delimitatore");
define('_AM_XNEWSLETTER_IMPORT_CSV_HEADER',"File CSV con riga d&#39;intestazione");
    define('_AM_XNEWSLETTER_IMPORT_CSV',"Il file CSV pu&ograve; essere di 1 colonna ( indirizzo email ) o 4 colonne ( indirizzo email | titolo | nome  | cognome )<br />Esempio: vedi &#39;sample1col.csv&#39; e &#39;sample4col.csv&#39; nella directory &#39;" . XOOPS_PATH . "/modules/xNewsletter/plug-ins&#39;");
define('_AM_XNEWSLETTER_IMPORT_XOOPSUSER',"Opzioni di importazione/sincronizzazione utenti Xoops");
define('_AM_XNEWSLETTER_IMPORT_XOOPSUSER_GROUPS',"Seleziona gruppi");
    define('_AM_XNEWSLETTER_NEWTASK',"Add New task");
    define('_AM_XNEWSLETTER_TASKLIST',"List task");
    define('_AM_XNEWSLETTER_TASK_ADD',"Add a task");
    define('_AM_XNEWSLETTER_TASK_EDIT',"Edit a task");
    define('_AM_XNEWSLETTER_TASK_DELETE',"Delete a task");
    define('_AM_XNEWSLETTER_TASK_ID',"Id");
define('_AM_XNEWSLETTER_TASK_LETTER_ID',"Messaggio email");
define('_AM_XNEWSLETTER_TASK_SUBSCR_ID',"Iscritto");
define('_AM_XNEWSLETTER_TASK_STATUS',"Stato");
    define('_AM_XNEWSLETTER_TASK_STARTTIME',"Starttime");
define('_AM_XNEWSLETTER_TASK_SUBMITTER',"Creato da");
define('_AM_XNEWSLETTER_TASK_CREATED',"Creato in data");
    define('_AM_XNEWSLETTER_TASK_ERROR_CREATE',"Error creating item in task list");
    define('_AM_XNEWSLETTER_TASK_NO_DATA',"No tasks waiting");
//Error NoFrameworks
    define('_AM_XNEWSLETTER_NOFRAMEWORKS',"Errore: You don't use the Frameworks \"admin module\". Please install this Frameworks");
    define('_AM_XNEWSLETTER_MAINTAINEDBY',"is maintained by the");
    define('_AM_XNEWSLETTER_SEND_ERROR_NO_LETTERCONTENT',"No text available for printing");
define('_AM_XNEWSLETTER_FORMSEARCH_SUBSCR_EXIST',"Cerca iscritto con indirizzo email");
define('_AM_XNEWSLETTER_SUBSCR_NO_CATSUBSCR',"Non ci sono iscritti con questo indirizzo email");
//version 1.2
define('_AM_XNEWSLETTER_IMPORT_ERROR_NO_PLUGIN',"Errore: non &egrave; stato possibile trovare il file 'plugins/%p.php'!");
define('_AM_XNEWSLETTER_IMPORT_ERROR_NO_FUNCTION',"Errore: non esiste la funzione &#39;xnewsletter_plugin_getdata_%f&#39;!");
//version 1.3
//General
define('_AM_XNEWSLETTER_GROUPS_EDIT','Modifica gruppo');
//
define('_AM_XNEWSLETTER_THEREARE_TEMPLATE',"Ci sono <span class='bold'>%s</span> modelli nel database");
//
define('_AM_XNEWSLETTER_IMPORT_END', "Fine");
define('_AM_XNEWSLETTER_IMPORT_AFTER_READ_DESC','&Egrave; possibile scegliere se importare gli indirizzi email dopo averli verificati oppure no.');
//
define('_AM_XNEWSLETTER_LETTER_CONTENT_DESC','Formato HTML');
define('_AM_XNEWSLETTER_LETTER_EMAIL_TEST_DESC', 'Uno o più indirizzi email separati da punto e virgola &#39;;&#39;');
//
define('_AM_XNEWSLETTER_SUBSCR_SEX_PREVIEW','Sig.');
define('_AM_XNEWSLETTER_SUBSCR_FIRSTNAME_PREVIEW','Paolo');
define('_AM_XNEWSLETTER_SUBSCR_LASTNAME_PREVIEW','Rossi');
define('_AM_XNEWSLETTER_SUBSCR_EMAIL_PREVIEW','username@example.com');
//
define('_AM_XNEWSLETTER_TEMPLATE_ADD',"Aggiungi modello");
define('_AM_XNEWSLETTER_TEMPLATE_EDIT',"Modifica modello");
define('_AM_XNEWSLETTER_TEMPLATE_DELETE',"Elimina modello");
define('_AM_XNEWSLETTER_TEMPLATE_ID',"Id");
define('_AM_XNEWSLETTER_TEMPLATE_TITLE',"Titolo");
define('_AM_XNEWSLETTER_TEMPLATE_DESCRIPTION',"Descrizione");
define('_AM_XNEWSLETTER_TEMPLATE_DESCRIPTION_DESC','');
define('_AM_XNEWSLETTER_TEMPLATE_CONTENT',"Contenuto");
define('_AM_XNEWSLETTER_TEMPLATE_CONTENT_DESC','
    Formato HTML
    <br />
    Questo modulo utilizza lo <a href="http://www.smarty.net/">Smarty template engine</a> di Xoops per generare i messaggi email.
    <br /><br />
    Variabili Smarty disponibili:
    <ul>
    <li>&lt;{$salutation}&gt; oppure &lt;{$sex}&gt;: il campo "Titolo" (subscr_sex) dell&#39;iscritto</li>
    <li>&lt;{$firstname}&gt;: il campo "Nome" (subscr_firstname) dell&#39;iscritto</li>
    <li>&lt;{$lastname}&gt;: il campo "Cognome" (subscr_lastname) dell&#39;iscritto</li>
    <li>&lt;{$email}&gt; oppure &lt;{$subscr_email}&gt;: il campo "Email" (subscr_email) dell&#39;iscritto</li>
    </ul>
    <ul>
    <li>&lt;{$letter_id}&gt;: il campo "id" (letter_id) del messaggio email</li>
    <li>&lt;{$title}&gt;: il campo "Titolo" (letter_title) del messaggio email</li>
    <li>&lt;{$content}&gt;: il campo "Contenuto" (letter_content) del messaggio email</li>
    <li>&lt;{$attachments}&gt;: array di allegati
        <br />
        <span style="font-size:0.9em">
        Per esempio:
        <br>
        &lt;ul&gt;
        <br>
        &lt;{foreach item="attachment" from=$attachments}&gt;
        <br>
        &lt;li&gt;&lt;a href="&lt;{$attachment.attachment_url}&gt;"&gt;&lt;{$attachment.attachment_name}&gt;&lt;/a&gt;&lt;/li&gt;
        <br>
        &lt;{/foreach}&gt;
        <br>
        &lt;/ul&gt;
        <br>
        mostrer&agrave; l&#39;elenco degli allegati collegati
        </span>
    </li>
    </ul>
    <ul>
    <li>&lt;{$date}&gt;: la data di invio in formato timestamp integer
        <br />
        <span style="font-size:0.9em">
        Per esempio:
        <br>
        &lt;{$date|date_format:"%d/%m/%Y"}&gt;
        <br>
        mostrer&agrave; la data di oggi come ' . date("d/m/Y") . '
        </span>
    </li>
    <li>&lt;{$unsubscribe_url}&gt;: il link per disinscriversi</li>
    </ul>
    <ul>
    <li>&lt;{$xoops_url}&gt;: l&#39;indirizzo principale del sito (e.g. http://localhost/)</li>
    <li>&lt;{$xoops_langcode}&gt;: il langcode del sito(e.g. it_IT)</li>
    <li>&lt;{$xoops_charset}&gt;: il charset del sito (e.g. UTF-8)</li>
    </ul>');
define('_AM_XNEWSLETTER_TEMPLATE_SUBMITTER',"Creato da");
define('_AM_XNEWSLETTER_TEMPLATE_CREATED',"Creato in data");
define('_AM_XNEWSLETTER_LETTER_CLONED',"Copia di %s");
define('_AM_XNEWSLETTER_CAT_INFO_DESC',"");
define('_AM_XNEWSLETTER_TEXTOPTIONS',"Opzioni testo");
define('_AM_XNEWSLETTER_TEXTOPTIONS_DESC',"Opzioni testo campo descrizione");
define('_AM_XNEWSLETTER_ALLOWHTML',"Abilita tag HTML");
define('_AM_XNEWSLETTER_ALLOWSMILEY',"Abilita emoticons");
define('_AM_XNEWSLETTER_ALLOWXCODE',"Abilita codici XOOPS");
define('_AM_XNEWSLETTER_ALLOWIMAGES',"Abilita immagini");
define('_AM_XNEWSLETTER_ALLOWBREAK',"Abilita interruzione di riga (linebreak)");
define('_AM_XNEWSLETTER_LETTER_ACTION_PRINT',"Stampa");
define('_AM_XNEWSLETTER_LETTER_SENDER',"Inviato da");
define('_AM_XNEWSLETTER_LETTER_SENT',"Inviato in data");
define('_AM_XNEWSLETTER_THEREARE_NOT_ACCOUNTS',"<span color='#FF0000'>Attenzione: non ci sono account email, crearne uno prima.</span>");
define('_AM_XNEWSLETTER_LETTER_SIZE',"Dimensione");
define('_AM_XNEWSLETTER_LETTER_EMAIL_SIZE',"Dimensione email");
define('_AM_XNEWSLETTER_LETTER_EMAIL_SIZE_DESC',"Dimensione stimata, non accurata");
define('_AM_XNEWSLETTER_LETTER_ATTACHMENT_SIZE',"Dimensione");
define('_AM_XNEWSLETTER_LETTER_ATTACHMENT_TOTALSIZE',"Dimensione allegati");
//
define('_AM_XNEWSLETTER_ATTACHMENT_SIZE',"Dimensione");
define('_AM_XNEWSLETTER_ATTACHMENT_MODE',"Allegato come");
define('_AM_XNEWSLETTER_ATTACHMENT_MODE_ASATTACHMENT',"Allegato");
define('_AM_XNEWSLETTER_ATTACHMENT_MODE_ASLINK',"Collegamento");
define('_AM_XNEWSLETTER_ATTACHMENT_MODE_AUTO',"Auto");
//
define('_AM_XNEWSLETTER_ACTIONS_ACTIVATE',"Attiva");
define('_AM_XNEWSLETTER_ACTIONS_UNACTIVATE',"Disattiva");
define('_AM_XNEWSLETTER_ACTIONS_EXEC',"Esegui");
define('_AM_XNEWSLETTER_FORMACTIVATEOK',"Iscritti attivati con successo");
define('_AM_XNEWSLETTER_FORMUNACTIVATEOK',"Iscritti disattivati con successo");
//
define('_AM_XNEWSLETTER_PROTOCOL_STATUS_EMPTY','');
define('_AM_XNEWSLETTER_PROTOCOL_STATUS_SAVED','Salvato');
    define('_AM_XNEWSLETTER_PROTOCOL_STATUS_ERROR_CREATE_TASK','Error creating item in task list');
define('_AM_XNEWSLETTER_PROTOCOL_STATUS_OK_SEND_TEST','Messaggio email correttamente inviato a indirizzo email di test (%recipient)');
define('_AM_XNEWSLETTER_PROTOCOL_STATUS_OK_SEND','Messaggio email inviato');
define('_AM_XNEWSLETTER_PROTOCOL_STATUS_ERROR_SEND','Errore invio -> %error');
define('_AM_XNEWSLETTER_PROTOCOL_STATUS_ERROR_PHPMAILER',"Errore phpmailer -> %error");
define('_AM_XNEWSLETTER_PROTOCOL_STATUS_ERROR_SEND_COUNT',"Errore: &#39;%error_count&#39; messaggi/o email su &#39;%total_count&#39; non inviati/o");
define('_AM_XNEWSLETTER_PROTOCOL_STATUS_OK_SEND_COUNT',"Inviati/o correttamente &#39;%total_count&#39; messaggi/o email");
    define('_AM_XNEWSLETTER_PROTOCOL_STATUS_OK_MAILINGLIST', "Handle mailing list successfully");
    define('_AM_XNEWSLETTER_PROTOCOL_STATUS_OK_SEND_MAILINGLIST', "Sending '%action_code' to mailing list successfully");
    define('_AM_XNEWSLETTER_PROTOCOL_STATUS_CRON', "Cron: %result_exec");
    define('_AM_XNEWSLETTER_PROTOCOL_STATUS_SKIP_IMPORT', "Attenzione: Import email addresses %subscr_email skipped");
    define('_AM_XNEWSLETTER_PROTOCOL_STATUS_ERROR_IMPORT', "Attenzione: import email addresses %subscr_email failed");
    define('_AM_XNEWSLETTER_PROTOCOL_STATUS_OK_IMPORT', "%result_text Subscription to category successful");
    define('_AM_XNEWSLETTER_PROTOCOL_STATUS_EXIST_IMPORT', "%result_text Subscription already exist");

define('_AM_XNEWSLETTER_PROTOCOL_CREATED_FILTER_FROM', "Creata dal");
define('_AM_XNEWSLETTER_PROTOCOL_CREATED_FILTER_TO', "al");
define('_AM_XNEWSLETTER_PROTOCOLLIST_BY_LETTER', "Ragruppa per lettera");
define('_AM_XNEWSLETTER_PROTOCOL_SHOW_ALL', "Mostra tutte");
define('_AM_XNEWSLETTER_PROTOCOL_DELETE_ALL', "Elimina tutte");

define('_AM_XNEWSLETTER_TASK_CREATED_FILTER_FROM', "Creato dal");
define('_AM_XNEWSLETTER_TASK_CREATED_FILTER_TO', "al");
define('_AM_XNEWSLETTER_TASK_STARTTIME_FILTER_FROM', "Starttime dal");
define('_AM_XNEWSLETTER_TASK_STARTTIME_FILTER_TO', "al");
define('_AM_XNEWSLETTER_TASK_ACTIONS_EXECUTE', "Esegui ora");
define('_AM_XNEWSLETTER_FORMEXECUTEOK', "Eseguito con successo");
define('_AM_XNEWSLETTER_TASK_SHOW_ALL', "Mostra tutti");
define('_AM_XNEWSLETTER_TASK_CONFIGS', "Configura &quot;Invio a pacchetti&quot;");
define('_AM_XNEWSLETTER_TASK_DELETE_ALL', "Elimina tutti");
define('_AM_XNEWSLETTER_TASK_RUN_CRON_NOW', "Esegui ora &quot;cron.php&quot;");
define('_AM_XNEWSLETTER_FORMSURERUNCRONNOW', "Sei certo di voler eseguire: <span class='bold red'>&quot;cron.php&quot;</span>");
define('_AM_XNEWSLETTER_FORMSURESEND', "Sei certo di voler inviare: <span class='bold red'>%s</span>");

//Buttons
define('_AM_XNEWSLETTER_NEWTEMPLATE',"Aggiungi modello");
define('_AM_XNEWSLETTER_TEMPLATELIST',"Elenco modelli");
// ???
define('_AM_ACCOUNTS_TYPE_PHPMAIL',"php mail()");
define('_AM_ACCOUNTS_TYPE_PHPSENDMAIL',"php sendmail()");
define('_AM_ACCOUNTS_TYPE_POP3',"pop before smtp");
define('_AM_ACCOUNTS_TYPE_SMTP',"smtp");
define('_AM_ACCOUNTS_TYPE_GMAIL',"gmail");
define('_AM_ACCOUNTS_TYPE_NOTREQUIRED',"Non richiesto");
define('_AM_ACCOUNTS_TYPE_NAME',"Nome account email");
define('_AM_ACCOUNTS_TYPE_YOURNAME',"Paolo Rossi");
define('_AM_ACCOUNTS_TYPE_YOUREMAIL',"nome@tuodominio.com");
define('_AM_ACCOUNTS_TYPE_USERNAME',"nome utente");
define('_AM_ACCOUNTS_TYPE_PWD',"password");
define('_AM_ACCOUNTS_TYPE_POP3_SERVER_IN',"pop3.tuodominio.com");
define('_AM_ACCOUNTS_TYPE_POP3_PORT_IN',"110");
define('_AM_ACCOUNTS_TYPE_POP3_SERVER_OUT',"mail.tuodominio.com");
define('_AM_ACCOUNTS_TYPE_POP3_PORT_OUT',"25");
define('_AM_ACCOUNTS_TYPE_SMTP_SERVER_IN',"imap.tuodominio.com");
define('_AM_ACCOUNTS_TYPE_SMTP_PORT_IN',"143");
define('_AM_ACCOUNTS_TYPE_SMTP_SERVER_OUT',"mail.tuodominio.com");
define('_AM_ACCOUNTS_TYPE_SMTP_PORT_OUT',"25");
define('_AM_ACCOUNTS_TYPE_GMAIL_USERNAME',"tuonomeutente@gmail.com");
define('_AM_ACCOUNTS_TYPE_GMAIL_SERVER_IN',"imap.gmail.com");
define('_AM_ACCOUNTS_TYPE_GMAIL_PORT_IN',"993");
define('_AM_ACCOUNTS_TYPE_SECURETYPE_IN',"tls");
define('_AM_ACCOUNTS_TYPE_GMAIL_SERVER_OUT',"smtp.gmail.com");
define('_AM_ACCOUNTS_TYPE_GMAIL_PORT_OUT',"465");
define('_AM_ACCOUNTS_TYPE_SECURETYPE_OUT',"ssl");
    define('_AM_ACCOUNTS_TYPE_CHECK',"Check the settings");
