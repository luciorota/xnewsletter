<?php   
/**
 * ****************************************************************************
 *  - A Project by Developers TEAM For Xoops - ( http://www.xoops.org )
 * ****************************************************************************
 *  XNEWSLETTER - MODULE FOR XOOPS
 *  Copyright (c) 2007 - 2012
 *  Goffy ( wedega.com )
 *
 *  You may not change or alter any portion of this comment or credits
 *  of supporting developers from this source code or any supporting
 *  source code which is considered copyrighted (c) material of the
 *  original comment or credit authors.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  ---------------------------------------------------------------------------
 *  @copyright  Goffy ( wedega.com )
 *  @license    GPL 2.0
 *  @package    xNewsletter
 *  @author     Goffy ( webmaster@wedega.com )
 *
 *  Version : 1 Mon 2012/11/05 14:31:32 :  Exp $
 * ****************************************************************************
 */
// Admin
define('_MI_XNEWSLETTER_NAME',"xNewsletter");
define('_MI_XNEWSLETTER_DESC',"Modulo per la gestione di newsletter");
//Menu
define('_MI_XNEWSLETTER_ADMENU1',"Riepilogo");
define('_MI_XNEWSLETTER_ADMENU2',"Account email");
define('_MI_XNEWSLETTER_ADMENU3',"Newsletter");
define('_MI_XNEWSLETTER_ADMENU4',"Iscritti");
define('_MI_XNEWSLETTER_ADMENU5',"Iscrizioni");
define('_MI_XNEWSLETTER_ADMENU6',"Messaggi email");
define('_MI_XNEWSLETTER_ADMENU7',"Allegati");
define('_MI_XNEWSLETTER_ADMENU8',"Registro azioni");
define('_MI_XNEWSLETTER_ADMENU9',"Mailing list");
define('_MI_XNEWSLETTER_ADMENU10',"Email errate/ritorni");
define('_MI_XNEWSLETTER_ADMENU11',"Manutenzione database");
define('_MI_XNEWSLETTER_ADMENU12',"Importa iscritti");
    define('_MI_XNEWSLETTER_ADMENU13',"Task list");
define('_MI_XNEWSLETTER_ADMENU99',"Informazioni");
define('_MI_XNEWSLETTER_SUBSCRIBE',"Iscrivi/Cancella");
define('_MI_XNEWSLETTER_LIST',"Lista messaggi email");
define('_MI_XNEWSLETTER_LIST_SUBSCR',"Lista iscritti");
define('_MI_XNEWSLETTER_CREATE',"Crea messaggio email");
//Blocks
define('_MI_XNEWSLETTER_CATSUBSCR_BLOCK_RECENT',"Sottoscrizioni recenti");
define('_MI_XNEWSLETTER_CATSUBSCR_BLOCK_DAY',"Sottoscrizioni di oggi");
define('_MI_XNEWSLETTER_LETTER_BLOCK_RECENT',"Messaggi email recenti");
define('_MI_XNEWSLETTER_LETTER_BLOCK_DAY',"Messaggi email di oggi");
define('_MI_XNEWSLETTER_LETTER_BLOCK_RANDOM',"Messaggi email a caso");
//Config
define('_MI_XNEWSLETTER_EDITOR',"Editor");
    define('_MI_XNEWSLETTER_KEYWORDS',"Parole chiave");
    define('_MI_XNEWSLETTER_KEYWORDS_DESC',"Insert here the parole chiave (separate da virgola).");
    define('_MI_XNEWSLETTER_ADMINPERPAGE',"Number of list entries in admin pages");
    define('_MI_XNEWSLETTER_ADMINPERPAGE_DESC',"Specifies how many items you want to display per page in the list.");
define('_MI_XNEWSLETTER_ADVERTISE',"Codice pubblicit&agrave;");
define('_MI_XNEWSLETTER_ADVERTISE_DESC',"Formato html");
define('_MI_XNEWSLETTER_SOCIALACTIVE',"Visualizza social network?");
define('_MI_XNEWSLETTER_SOCIALACTIVE_DESC',"Selezionare &#39;" . _YES . "&#39; per visualizzare pulsanti social network");
define('_MI_XNEWSLETTER_SOCIALCODE',"Codice social network");
define('_MI_XNEWSLETTER_SOCIALCODE_DESC',"Formato html");
define('_MI_XNEWSLETTER_ATTACHMENT_MAXSIZE',"Massima dimensione allegati");
define('_MI_XNEWSLETTER_ATTACHMENT_MAXSIZE_DESC',"Massima dimensione allegati (byte).");
define('_MI_XNEWSLETTER_ATTACHMENT_MIMETYPES',"Mime-type");
define('_MI_XNEWSLETTER_ATTACHMENT_MIMETYPES_DESC',"Mime-type allegati (selezioni multiple consentite).");
define('_MI_XNEWSLETTER_ATTACHMENT_PATH',"Percorso/path di upload allegati");
define('_MI_XNEWSLETTER_ATTACHMENT_PATH_DESC',"Percorso/path directory (contenuta in " . XOOPS_ROOT_PATH . "/uploads ), con slash prima e dopo.");
define('_MI_XNEWSLETTER_USE_MAILINGLIST',"Attiva gestore mailing list");
    define('_MI_XNEWSLETTER_USE_MAILINGLIST_DESC',"Se siete titolari di mailing list esistenti, &egrave; possibile sincronizzare, iscrivere, disiscrivere utilizzando la mailing list.<br /><b>Attenzione: questo modulo non pu&ograve; creare mailing list</b>.<br />Se selezionate &#39;" . _YES . "&#39; sar&agrave; disponibile un nuovo tab nel Pannello di Controllo di questo modulo.");
define('_MI_XNEWSLETTER_GROUPS_WITHOUT_ACTKEY',"Gruppi autorizzati a iscriversi/cancellarsi senza email di conferma");
define('_MI_XNEWSLETTER_GROUPS_WITHOUT_ACTKEY_DESC',"Gli utenti membri dei gruppi selezionati possono iscriversi/cancallarsi/modificare la loro iscrizione alla newsletter senza inviare l'email di conferma");
define('_MI_XNEWSLETTER_GROUPS_CHANGE_OTHER',"Gruppi autorizzati a modificare le iscrizioni altrui");
    define('_MI_XNEWSLETTER_GROUPS_CHANGE_OTHER_DESC',"Gli utenti membri dei gruppi selezionati possono modificare le iscrizioni di altre persone. Deleting the registration is not possible. This groups need also the permission to list the subscribers of a newsletter category. It is recommended to give this groups also the permission to create newsletters.");
define('_MI_XNEWSLETTER_USE_SALUTATION',"Utilizzare titoli iscritti");
define('_MI_XNEWSLETTER_USE_SALUTATION_DESC',"Selezionare &#39;" . _YES . "&#39; per utilizzare titoli quali 'Sig.', 'Sig.ra',...");
define('_MI_XNEWSLETTER_SEND_IN_PACKAGES',"Email per pacchetto");
define('_MI_XNEWSLETTER_SEND_IN_PACKAGES_DESC',"Numero di email per pacchetto. 0 significa che tutte le email saranno inviate immediatemente. You can use this option only, if you can start cronjobs with external programs.");
define('_MI_XNEWSLETTER_SEND_IN_PACKAGES_TIME',"Intervallo tra pacchetti (minuti)");
define('_MI_XNEWSLETTER_SEND_IN_PACKAGES_TIME_DESC',"Intervallo di tempo tra l'invio di un pacchetto e il successivo. Parametro utilizzato solo se è attivo l'invio a pacchetti.");
    define('_MI_XNEWSLETTER_UPGRADEFAILED',"Error while updating module");
// version 1.2
    define('_MI_XNEWSLETTER_SUBSCRINFO_BLOCK',"Info Newsletter");
    define('_MI_XNEWSLETTER_SUBSCRINFO_TEXT_BLOCK',"If you want to be informed in time, then subscribe to our newsletter");
// version 1.3
define('_MI_XNEWSLETTER_WELCOME_MESSAGE',"Messaggio di benvenuto");
define('_MI_XNEWSLETTER_WELCOME_MESSAGE_DESC',"Formato html");
define('_MI_XNEWSLETTER_WELCOME',"<h2>Benvenuti nel nostro sistema di gestione newsletter</h2>Speriamo, con le nostre newsletter, di tenervi sempre informati. Il sistema consente di iscriversi a pi&ugrave; newsletter se sono disponibili. Se non desiderate pi&ugrave; ricevere le nostre newsletter &egrave; possibile disiscriversi qui. &Egrave; anche possibile disiscriversi cliccando il link presente nei messaggi email gia ricevuti.");
define('_MI_XNEWSLETTER_DATEFORMAT', "Formato data");
define('_MI_XNEWSLETTER_DATEFORMATDSC', "Formato di default per le date. <br />Più informazioni qui: <a href='http://www.php.net/manual/en/function.date.php'>http://www.php.net/manual/en/function.date.php</a>");
define('_MI_XNEWSLETTER_CONFIRMATION_TIME', "Validità email di conferma");
define('_MI_XNEWSLETTER_CONFIRMATION_TIME_DESC', "L'email di conferma sarà valida se inviate entro...");
define('_MI_XNEWSLETTER_CONFIRMATION_TIME_0', "sempre valida");
define('_MI_XNEWSLETTER_CONFIRMATION_TIME_1', "1 ora");
define('_MI_XNEWSLETTER_CONFIRMATION_TIME_6', "6 ore");
define('_MI_XNEWSLETTER_CONFIRMATION_TIME_24', "1 giorno");
define('_MI_XNEWSLETTER_CONFIRMATION_TIME_48', "2 giorni");
define('_MI_XNEWSLETTER_MAXATTACHMENTS',"Numero massimo di allegati");
define('_MI_XNEWSLETTER_MAXATTACHMENTS_DESC',"");
//
define('_MI_XNEWSLETTER_ADMENU_TEMPLATES',"Modelli");
define('_MI_XNEWSLETTER_EDITOR_DESC',"");
define('_MI_XNEWSLETTER_TEMPLATE_EDITOR',"Editor modelli");
define('_MI_XNEWSLETTER_TEMPLATE_EDITOR_DESC',"");

define('_MI_XNEWSLETTER_CONFCAT_EDITOR',"");
define('_MI_XNEWSLETTER_CONFCAT_EDITOR_DESC',"");
define('_MI_XNEWSLETTER_CONFCAT_INDEX',"");
define('_MI_XNEWSLETTER_CONFCAT_INDEX_DESC',"");
define('_MI_XNEWSLETTER_CONFCAT_ATTACHMENT',"");
define('_MI_XNEWSLETTER_CONFCAT_ATTACHMENT_DESC',"");
define('_MI_XNEWSLETTER_CONFCAT_FORMAT',"");
define('_MI_XNEWSLETTER_CONFCAT_FORMAT_DESC',"");
define('_MI_XNEWSLETTER_CONFCAT_SUBSCR',"");
define('_MI_XNEWSLETTER_CONFCAT_SUBSCR_DESC',"");
define('_MI_XNEWSLETTER_CONFCAT_TASK',"Invio a pacchetti");
define('_MI_XNEWSLETTER_CONFCAT_TASK_DESC',"");
