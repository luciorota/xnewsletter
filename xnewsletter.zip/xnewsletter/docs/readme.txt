Read Me First
=============
 1. License
 _____________________________________________________________________
 
 This source code is released under the GPL.
 A copy of the license in provided in this package in the file
 named LICENSE.txt

2. What is xnewsletter?
 _____________________________________________________________________
 
 newsletter module for xoops

 3. Requirements
 _____________________________________________________________________
 
 - PHP version >= 5.2.0
 - ModuleClasses in /Frameworks (download it from here: http://goo.gl/Bmknt)  
 
 
 4. Installation
 _____________________________________________________________________
 
 Simply upload these module folder to a directory of your xoops modules folder,
 and install it via xoops modules administration panel. You can configure 
 it through xnewsletter module control panel.
 Detailed instructions on installing modules are available in the 
 XOOPS Operations Manual (http://goo.gl/adT2i)
 
 5. Tutorial
_____________________________________________________________________

  You can find a more detailed Tutorial here: http://goo.gl/bz94i
